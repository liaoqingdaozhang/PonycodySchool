define([
	'main',
	'service/meetService',
	'service/placeService',
	'vue'
], function(App,meetService,placeService,Vue) {
	var vm = new Vue({
		el: '#app',
		data: {
			marks:[],
			size:50,
			idLittleThen:null,
			nickName:"",
			placeName:"",
			placeTypeId:"-1"
		},
		beforeMount: function () {
			this.loadTypes();
			this.loadList();
		},
		
		methods: {	
			loadTypes:function(){
				console.log("获取会面类型");
				placeService.getTypesTree(res=>{
					let types = res.body;
					this.types = types;
				});
			},
			search:function(e){
				this.idLittleThen = null;
				this.marks = [];
				this.loadList();
				e.preventDefault();
			},
			loadList:function(){
				console.log("查找会面记录");
				let condition = {};
				let {nickName,placeName,placeTypeId} = this;
				if(nickName!=null && nickName!="")
				  condition.nickName = nickName;
				if (placeName != null && placeName!="")
				  condition.placeName = placeName;
				if (placeTypeId != null && placeTypeId!="-1")
				  condition.placeTypeId = placeTypeId;

				condition.size = this.size;
				if(this.idLittleThen!=null)
					condition.idLittleThen = this.idLittleThen;
				meetService.findMeets(condition,res=>{
					let marks = res.body;
					let oldMarks = this.marks;
					this.marks = oldMarks.concat(marks);
					if(marks!=null&& marks.length>0){
						let last = marks[marks.length-1];
						this.idLittleThen = last.id;
					}
				});
			},
			
			pageScroll:function(e){
				var container = e.srcElement;
				if(container.scrollHeight>container.clientHeight && container.scrollHeight-(container.clientHeight+container.scrollTop)<1){
					App.debounce (this.loadList,500);					
				}
			},
			
		}
	})
	
});
