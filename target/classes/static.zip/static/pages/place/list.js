define([
	'main',
	'service/placeService',
	'service/userService',
	'vue'
], function(App,placeService,userService,Vue) {
	window.init = function() {
		console.log("map inited");
	}
		 
	window.loadScript = function() {
		  var script = document.createElement("script");
		  script.type = "text/javascript";
		  script.src = "https://map.qq.com/api/js?v=2.exp&key=HGNBZ-SFDAF-GJ2JO-JSOT5-GRZSO-DHBXF&callback=init";
		  document.body.appendChild(script);
	}
		 
	window.loadScript();
	
	var vm = new Vue({
		el: '#app',
		data: {
			types:[],
			places:[],
			
			searchName:"",
			linkName:"",
			linkCode:"",
			searchTypeId:'-1',
			size:50,
			idLittleThen:null,
			//data for editor
			place:{type:{},addrs:{},checkers:[]},
			showEditor:false,
			provinces:[],
			cities:[],
			areas:[],
			map:null,
			lat:null,
			lng:null,
			checkerMobile:'',
			//data for checker picker
			checkerName:'',
			currentChecker:{},
			validate:{},
			
			uploading:false
		},
		computed: {
			checkerList: function () {
				let list = [];
				let checkers = this.place.checkers;
				if(checkers!=null){
					for(var i=0;i<checkers.length;i++){
						list.push(checkers[i].nickName);
					}
					return list.join("、");
				}
				return "";
			}
		},
		beforeMount: function () {
			this.loadTypes();
			this.loadList();
			this.provinces  = App.areas;
		},
		
		methods: {	
			getEmptyPlace:function(){
				return {type:{},addrs:{},checkers:[]};
			},
			getCityList:function(p){
				let provinces = App.areas;
				for(var i=0;i<provinces.length;i++){
					let one = provinces[i];
					if(one.name == p){
						return one.cityList;
					}
				}
				return [];
			},
			getAreaList:function(p,city){
				let cityList = this.getCityList(p);
				
				for(var i=0;i<cityList.length;i++){
					let one = cityList[i];
					if(one.name == city){
						return one.areaList;
					}
				}
				return [];
			},
			changeOption:function(e){
				let srcElement = e.srcElement;
				if(srcElement.id == 'placeTypePicker'){
					let selectedOption = srcElement.children[srcElement.selectedIndex];
					this.searchTypeId = selectedOption.value;
				}else if(srcElement.id == 'provincePicker'){
					let selectedOption = srcElement.children[srcElement.selectedIndex];
					let province = selectedOption.value;
					this.place.addrs.province = province;
					this.cities = this.getCityList(province);
				}else if(srcElement.id == 'cityPicker'){
					let selectedOption = srcElement.children[srcElement.selectedIndex];
					let city = selectedOption.value;
					this.place.addrs.city = city
					this.areas = this.getAreaList(this.place.addrs.province,city);
				}else if(srcElement.id == 'areaPicker'){
					let selectedOption = srcElement.children[srcElement.selectedIndex];
					let area = selectedOption.value;
					this.place.addrs.area = area
				}
			},
			
			bindAddr:function(type,value){
				if(type=="province"){
					this.cities = this.getCityList(value);
				}else if(type=='city'){
					this.areas = this.getAreaList(this.place.addrs.province,this.place.addrs.city);
				}
			},
			
			search:function(e){
				this.idLittleThen = null;
				this.places = [];
				this.loadList();
				e.preventDefault();
			},
			loadTypes:function(){
				console.log("获取打卡点类型");
				placeService.getTypesTree(res=>{
					let types = res.body;
					this.types = types;
				});
			},
			loadList:function(){
				console.log("查找打卡点");
				let condition = {};
				let {searchName,searchTypeId,linkName,linkCode} = this;
				if(searchName!=null && searchName!="")
				  condition.name = searchName;
				if (searchTypeId != null && searchTypeId!="-1")
				  condition.typeId = searchTypeId;
				if (linkName != null && linkName!="")
				  condition.linkName = linkName;
				if (linkCode != null && linkCode!="")
				  condition.linkCode = linkCode;
				  
				
				condition.pageSize = this.size;
				if(this.idLittleThen!=null)
					condition.idLittleThen = this.idLittleThen;
				else
					this.places = [];
				
				console.log(condition);
				placeService.findPlaces(condition,res=>{
					let places = res.body;
					let oldPlaces = this.places;
					this.places = oldPlaces.concat(places);
					if(this.places!=null&& this.places.length>0){
						let last = this.places[this.places.length-1];
						this.idLittleThen = last.id
					}
				});
			},
			
			pageScroll:function(e){
				var container = e.srcElement;
				if(container.scrollHeight>container.clientHeight && container.scrollHeight-(container.clientHeight+container.scrollTop)<1){
					App.debounce (this.loadList,500);					
				}
			},
			editPlace:function(e){
				let  placeId= e.target.dataset.id;
				placeService.getPlace(placeId,res=>{
					this.showEditor = true;
					this.place = res.body;
					if(this.place.addr!=null && this.place.addr!=''){
						let addrs = this.place.addr.split("/");
						this.place.addrs = {};
						this.place.addrs.province = addrs[0];
						this.bindAddr("province",addrs[0]);
						this.place.addrs.city = addrs[1];
						this.bindAddr("city",addrs[1]);
						this.place.addrs.area = addrs[2];
						if(this.place.checkers==null)
							this.place.checker = [];
					}
				})
				
				e.preventDefault();
			},
			
			create:function(e){
				this.place = {addrs:{},checkers:[]},
				this.showEditor = true;
				e.preventDefault();
			},
			
			locate:function(e){
				$('#location').modal({});
				if(this.map==null){
					if(this.lat==null){
						this.lat = 30.273893;
					}
					if(this.lng==null){
						this.lng = 120.170517;
					}
					let thisPage = this;
		            // 创建地图
		            this.map = new qq.maps.Map(document.getElementById("mapContainer"), {
		            	center: new qq.maps.LatLng(thisPage.lat,thisPage.lng),
		                zoom: 8,     // 地图缩放级别
		                mapStyleId: 'style1',  // 该key绑定的style1对应于经典地图样式，若未绑定将弹出无权限提示窗
		                draggableCursor : 'crosshair',     //设置鼠标拖拽元素样式
		                draggingCursor : 'crosshair'       //设置鼠标移动样式	
		            });
		            qq.maps.event.addListener(this.map, 'click', function(event) {
		            	thisPage.lat = event.latLng.getLat();
		            	thisPage.lng = event.latLng.getLng();
		            	
		            });
		            e.preventDefault();
				}
			},
			confirmLaction:function(e){
				if(this.lat!=null){
					this.place.position =  "POINT("+this.lat+" "+this.lng+")";
				}
				$('#location').modal('hide');
				this.$forceUpdate();
				e.preventDefault();
			},
			deletePlace:function(e){
				let  placeId= e.target.dataset.id;
				let deleteOK =  window.confirm("您确实要删除这个打卡点吗");
				if(deleteOk){
					placeService.deletePlace(placeId,res=>{
						this.loadList();
					});
				}
			},
			savePlace:function(e){
				let addr = this.place.addrs.province+"/"+this.place.addrs.city+"/"+this.place.addrs.area;
				
				this.place.addr = addr;
				let validateResult = this.doValidate();
				
				
				if(validateResult==false)
					return ;
				
				console.log(JSON.stringify(this.place));
				placeService.savePlace(this.place,res=>{
					this.idLittleThen = null;
					this.loadList();
					this.place =  this.getEmptyPlace();
					this.showEditor = false;
				})
				
				e.preventDefault();
				
			},
			doValidate:function(){
				if(this.validate==null)
					this.validate = {};
				if(this.validate.addrs == null)
					this.validate.addrs = {};
				
				if(this.place.name ==null || this.place.name == '')
					this.validate.name = 'err';
				else 
					delete this.validate.name;
				
				if(this.place.typeId == null || this.place.typeId == '' || this.place.typeId == '-1')
					this.validate.typeId = 'err';
				else 
					delete this.validate.typeId;
				
				if(this.place.linkName == null || this.place.linkName == '')
					this.validate.linkName = 'err';
				else
					delete this.validate.linkName;
				
				if(this.place.linkCode == null || this.place.linkCode == '')
					this.validate.linkCode = 'err';
				else
					delete this.validate.linkCode
					
				if(this.place.addrs.province == null || this.place.addrs.province == '' || this.place.addrs.province == '-1')
					this.validate.province = 'err';
				else
					delete this.validate.province;
				
				if(this.place.addrs.city == null || this.place.addrs.city == '' || this.place.addrs.city == '-1')
					this.validate.city = 'err';
				else
					delete this.validate.city;
			
				if(this.place.addrs.area == null || this.place.addrs.area == '' || this.place.addrs.area == '-1')
					this.validate.area = 'err';
				else
					delete this.validate.area;
				
				if(this.place.addrDetail == null || this.place.addrDetail == '')
					this.validate.addrDetail = 'err';
				else
					delete this.validate.addrDetail

				if(this.place.position == null || this.place.position == '')
					this.validate.position = 'err';
				else
					delete this.validate.position
				
				if(this.place.introduce == null || this.place.introduce == '')
					this.validate.introduce = 'err';
				else
					delete this.validate.introduce
				
				this.$forceUpdate();
				for(key in this.validate){
					if(this.validate[key] == 'err'){
						return false
					}
				}
				
			},
			closeEditor:function(){
				this.showEditor = false;
			},
			
			addChecker:function(e){
				
				$('#checkerPicker').modal('show');
				e.preventDefault();
			},
			findChecker:function(e){
				if(this.checkerMobile!=null && this.checkerMobile!=''){
					userService.findByMobile(this.checkerMobile,res=>{
						let user = res.body;
						if(user!=null){
							this.currentChecker = user;
							this.checkerName = user.nickName;
						}
					})
				}
				e.preventDefault();
			}
			
			,
			setAsChecker:function(e){
				if(this.place.checkers==null){
					this.place.checkers = [];
				}
				this.place.checkers.push(this.currentChecker);
				$('#checkerPicker').modal('hide');
				e.preventDefault();
				this.checkerName = ''; 
				this.checkerMobile = '';
			},
			
			uploadPhotos:function(e){
				
				$('#photos').modal('show');
			},
			uploadLog:function(e){
				
			}
		}
	})
	
});
