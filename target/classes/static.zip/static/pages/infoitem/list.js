define([
	'main',
	'service/placeService',
	'url',
	'vue'
], function(App,placeService,urlUtil,Vue) {
	var vm = new Vue({
		el: '#app',
		data: {
			items:[],
			typePath:"",
			currentName:"",
			options:[],
			currentOption:"",
			currentItem:{"notNull":false,"inputType":"radio"},
			validate:{}
			
		},
		beforeMount: function () {
			this.getItems();
		},
		
		methods: {	
			changeOption:function(e){
				let srcElement = e.srcElement;
				let inputType = srcElement.children[srcElement.selectedIndex].value;
				this.currentItem.inputType = inputType;
			},
			create:function(e){
				$('#editor').modal({});
				e.preventDefault();
			},
			back:function(e){
				window.location.href='../placetype/list.html';
				e.preventDefault();
			},
			editItem:function(e){
				let  itemId= e.target.dataset.id;
				placeService.getInfoItem(itemId,res=>{
					this.currentItem = res.body;
					if(this.currentItem.inputType=='radio'|| this.currentItem.inputType=='check'){
						if(this.currentItem.options!=null && this.currentItem.options.length>0){
							this.options = JSON.parse(this.currentItem.options);
						}
					}
					$('#editor').modal({});
				})
				
				
				e.preventDefault();
			},
			deleteItem:function(e){
				console.log("删除");
			},
			
			save:function(e){
				if(this.currentItem.name=='' || this.currentItem.name==null){
					this.validate.name = "err";
				}else{
					delete this.validate.name;
					console.log(this.currentItem);
					if(this.currentItem.inputType=='radio' || this.currentItem.inputType == 'check'){
						this.currentItem.options = JSON.stringify(this.options);
					}
					placeService.saveInfoItem(this.currentItem,res=>{
						this.getItems();
						 $('#editor').modal('hide')
					})
				}
				
				this.$forceUpdate();
			},
			getItems:function(){
				placeService.getItems(res=>{
					let items = res.body;					
					this.items = items;
				});
			},
			
			saveOption:function(e){
				if(this.currentOption=='' || this.currentOption==null){
					this.validate.currentOption = "err";
					this.$forceUpdate()
					return;
				}else{
					delete this.validate.currentOption ;
					this.options.push(this.currentOption);
					this.currentOption = '';
				}
				
			},
			
			deleteOption:function(e){
				let index = e.target.parentElement.parentElement.rowIndex-1;
				this.options.splice(index,1);
			}
			
			
		
		}
	})
	
});
