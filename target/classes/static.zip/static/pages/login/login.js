define([
    "main",
    'service/userService',
    'vue'
], function (App, userService,Vue) {
	
	
	var vm = new Vue({
		el: '#app',
		data: {
			errMsg:"",
			hasError:false,
			loginName:"",
			password:""
		},

		methods: {
			login: function (e) {

				userService.login(this.loginName,this.password,
						res=>{

							let user = res.body;
							window.sessionStorage.setItem("currentUser",JSON.stringify(user));
							window.location.href= '../home/home.html';
						},
						res=>{
							this.errMsg = res.errMsg;
							this.hasError = true;
						});
				
			}
		}
	})
});
