define([
	'main',
	'service/userService',
	'vue'
], function(App,userService,Vue) {
	var user = userService.getCurrentUser();
	
	var vm = new Vue({
		el: '#app',
		data: {
			user:user,
			moduleUrl:"about:blank;",
		},
		
		methods: {			
			loadModule: function (name,url) {
				console.log ("加载模块："+name);
				this.moduleUrl = url;
				
			}
		}
	})
	
	window.showLoading=function(){
		$("#loading").addClass("show");
	}
	window.hideLoading= function(){
		$("#loading").removeClass("show");
	}
});
