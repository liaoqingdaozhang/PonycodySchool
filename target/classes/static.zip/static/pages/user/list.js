define([
	'main',
	'service/userService',
	'vue'
], function(App,userService,Vue) {
	var user = userService.getCurrentUser();
	var vm = new Vue({
		el: '#app',
		data: {
			users:[],
			user:user,
			size:50,
			idLittleThen:null,
			wxNickName:"",
			nickName:"",
			mobile:"",
			gender:null
		},
		beforeMount: function () {
			this.loadList();
		},
		
		methods: {	
			
			changeOption:function(e){
				let srcElement = e.srcElement;
				let selectedOption = srcElement.children[srcElement.selectedIndex];
				this.gender = 1*selectedOption.value;
			},
			search:function(e){
				this.idLittleThen = null;
				this.users = [];
				this.loadList();
				e.preventDefault();
			},
			loadList:function(){
				console.log("查找用户");
				let condition = {};
				let {nickName,wxNickName,gender,mobile} = this;
				if(nickName!=null && nickName!="")
				  condition.nickName = nickName;
				if (wxNickName != null && wxNickName!="")
				  condition.wxNickName = wxNickName;
				if (gender != null && gender!="-1")
				  condition.gender = gender;
				if (mobile != null && mobile!="")
				  condition.mobile = mobile;
				  
				
				condition.size = this.size;
				if(this.idLittleThen!=null)
					condition.idLittleThen = this.idLittleThen;
				userService.findUsers(condition,res=>{
					let users = res.body;
					let oldUsers = this.users;
					this.users = oldUsers.concat(users);
					if(users!=null&& users.length>0){
						let last = users[users.length-1];
						this.idLittleThen = last.id
					}
				});
			},
			
			pageScroll:function(e){
				var container = e.srcElement;
				if(container.scrollHeight>container.clientHeight && container.scrollHeight-(container.clientHeight+container.scrollTop)<1){
					App.debounce (this.loadList,500);					
				}
			},
			
		}
	})
	
});
