define([
	'main',
	'service/placeService',
	'vue'
], function(App,placeService,Vue) {
	var vm = new Vue({
		el: '#app',
		data: {
			types:[],
			currentName:"",
			type:null,
			children:null,
			items:[],
			itemIds:[],
			currentTypeId:null
		},
		beforeMount: function () {
			this.loadList();
		},
		
		methods: {	
			
			loadList:function(){
				console.log("查找类目");
				if(this.children==null)
					placeService.getTypes(res=>{
						let types = res.body;					
						this.types = types;
					});
				else
					this.loadChildren(this.parentId);
			},
			
			loadChildren:function(pId){
				placeService.getChildrenTypes(pId,res=>{
					let children = res.body;					
					this.children = children;
				});
			},
			
			infoItems:function(e){
				let  typeId = e.target.dataset.id;
				this.currentTypeId = typeId;
				placeService.getTypeItems(typeId,res=>{
					let r =  res.body;
					let allItems = r.items;
					let itemIds = r.itemIds;
					this.itemIds = itemIds;
					this.items = allItems;
					
				});
				$('#selectInfoItems').modal('show');
				e.preventDefault();
			},
			
			saveItems:function(e){
				let itemIds = this.itemIds;
				placeService.saveTypeItems(this.currentTypeId,itemIds,res=>{
					this.items=[],
					this.itemIds=[],
					$('#selectInfoItems').modal('hide');
				});
				e.preventDefault();
			},
			
			save:function(e){
				let type = this.type;
				type.name = this.currentName;
				if(type.id==null){
					placeService.createType(type,res=>{
						this.loadList();
					})
				}else{
					placeService.updateType(type,res=>{
						this.loadList();
					});
				}
			},
			viewChildren:function(e){
				let  parentId = e.target.dataset.id;
				this.parentId = parentId;
				$('#sideChildrenViewer').modal({});
				this.loadChildren(parentId);
				
			},
			create:function(e){
				this.type = {};
				this.currentName = "";
				$('#editor').modal({});
				e.preventDefault();
			},
			createChildren:function(){
				this.type = {parentId:this.parentId};
				this.currentName = "";
				$('#editor').modal({});
				e.preventDefault();
			},
			edit:function(e){
				let  typeId = e.target.dataset.id;
				let type = placeService.loadType(typeId,res=>{
					this.type = res.body;
					this.currentName = this.type.name;
				})
				$('#editor').modal({})
			},
			deleteType:function(e){
				let  typeId = e.target.dataset.id;
				placeService.removeType(typeId,res=>{
					this.loadList();
				})
			},
			closeChildrenView:function(){
				this.children = null;
			}
		}
	})
	
});
