/**
 * Created by boil on 2015-12-15.
 */
requirejs.config({
	shim: {
		'bootstrap': {
            deps: ['jquery']
        },
	},
	
    paths: {
        jquery: 'jquery-3.2.1', 
        bootstrap:'../bootstrap/js/bootstrap',
        main: 'main',
        service: 'service',
        url: 'url',
        vue:"vue"
    }
});


require([
    'jquery',
    'main',
    'bootstrap',
    'vue'
], function (jquery, app) {
    app.initialize();
});

