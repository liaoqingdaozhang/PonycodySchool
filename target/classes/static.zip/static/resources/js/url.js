/**
 * Created by boil on 2016-01-15.
 */
define(['main'], function (App) {

    return {
        getUrlParameter: function (key, url) {
            if (!url) {
                url = window.location.search.substr(1);
            }
            var reg = new RegExp("(^|&)" + key + "=([^&]*)(&|$)");
            var r = url.match(reg);
            if (r != null) return unescape(r[2]);
            return null;
        }
    }
});
