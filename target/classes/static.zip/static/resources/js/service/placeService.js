define([
	"main"
], function(App) {
	return {
		getTypes: function (success) {
			App.doGet(
				"/place/types",
				null,
				true,
				success
			);
		},
		
		getTypesTree: function (success) {
			App.doGet(
				"/place/types/tree",
				null,
				true,
				success
			);
		},
		
		getChildrenTypes: function (pId,success) {
			App.doGet(
				"/place/types?parentId="+pId,
				null,
				true,
				success
			);
		},
		loadType: function (id,success) {
			App.doGet(
				"/place/type/"+id,
				null,
				true,
				success
			);
		},
		createType: function (type, success) {
			App.doPost(
				"/place/type/create",
				type,
				true,
				App.contentType.json,
				success
			);
		},
		updateType: function (type, success) {
			App.doPost(
				"/place/type/update",
				{id:type.id,name:type.name},
				true,
				App.contentType.json,
				success
			);
		},
		removeType: function (id, success) {
			App.doPost(
				"/place/type/delete",
				{ id: id },
				true,
				App.contentType.formData,
				success
			)
		},
		
		getTypeItems:function(typeId,success){
			App.doGet(
					"/place/type/items?typeId="+typeId,
					null,
					true,
					success
				);
		},
		
		saveTypeItems:function(typeId,itemIds,success){
			App.doPost(
					"/place/type/items/"+typeId,
					itemIds,
					true,
					App.contentType.json,
					success
				);
		},
		
		getItems:function(success){
			App.doGet(
					"/place/items",
					null,
					true,
					success
				);
		},
		saveInfoItem: function (item, success) {
			App.doPost(
				"/place/item/save",
				item,
				true,
				App.contentType.json,
				success
			);
		},
		getInfoItem:function(itemId,success){
			App.doGet(
					"/place/item/"+itemId,
					null,
					true,
					success
				);
		},
		findPlaces:function(condition,success){
			App.doPost(
					"/place/find",
					condition,
					true,
					App.contentType.formData,
					success
				);
		},
		getPlace:function(placeId,success){
			App.doGet(
					"/place/load/"+placeId,
					null,
					true,
					success
				);
		},
		savePlace:function(place,success){
			App.doPost(
					"/place/save",
					place,
					true,
					App.contentType.json,
					success
				);
		},
		deletePlace:function(id,success){
			App.doGet(
					"/place/delete/"+placeId,
					null,
					true,
					success
				);
		}
		
	}
});
