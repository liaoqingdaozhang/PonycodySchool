define([
	"main"
], function(App) {
	return {
		
		
		findMeets:function(condition,success){
			App.doPost(
				"/mark/list",
				condition,
				true,
				App.contentType.formData,
				success
			);
		},
		
	}
});
