define([
	"main"
], function(App) {
	return {
		getCurrentUser: function() {
			var userStr = window.sessionStorage.getItem("currentUser");
			var user = null;
			if(userStr!=null){
				user = JSON.parse(userStr);
			}
			if (user) {
				return user;
			}else{
                window.top.location.href = '../../pages/login/login.html'
            }
		},
		login:function(loginName,password,success,fail){
			App.doPost(
					"/employee/login",
					{loginName:loginName,password:password},
					true,
					App.contentType.formData,
					success,
					fail
				);
		},
		
		findUsers:function(condition,success){
			App.doPost(
				"/user/list",
				condition,
				true,
				App.contentType.formData,
				success
			);
		},
		findByMobile:function(mobile,success){
			App.doGet(
					"/user/find/"+mobile,
					null,
					true,
					success
				);
		}
	}
});
