define([
	"main"
], function(App) {
	return {
		list: function (success) {
			App.doGet(
				"/position/list",
				null,
				true,
				success
			);
		},
		load: function (id,success) {
			App.doGet(
				"/position/load/"+id,
				null,
				true,
				success
			);
		},
		create: function (name, success) {
			ajax.doPost(
				"/position/create",
				{ name: name },
				true,
				App.contentType.formData,
				success
			);
		},
		update: function (position, success) {
			ajax.doPost(
				"/position/update",
				position,
				true,
				App.contentType.json,
				success
			);
		},
		remove: function (id, success) {
			ajax.doPost(
				"/position/delete",
				{ id: id },
				true,
				App.contentType.formData,
				success
			)
		},
		 
		
	}
});
