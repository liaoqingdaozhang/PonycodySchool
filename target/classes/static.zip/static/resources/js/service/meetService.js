define([
	"main"
], function(App) {
	return {
		
		
		findMeets:function(condition,success){
			App.doPost(
				"/meet/list",
				condition,
				true,
				App.contentType.formData,
				success
			);
		},
		
	}
});
