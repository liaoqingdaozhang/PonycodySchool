define([
	"main"
], function(App) {
	return {
		getWorkStatuses:function(success){
			App.doGet("/asset/workstatuses",null,true,success);
		},
		getStockStatuses: function (success) {
			App.doGet("/asset/stockstatuses",null,true, success);
		},
		getBillStatuses:function(success){
			App.doGet("/asset/bill/statuses",null,true, success);
		},
		getInboundTypes: function (success) {
			App.doGet("/inbound/types",null, true,success);
		},
		getOutboundTypes: function (success) {
			App.doGet("/outbound/types",null,true, success);
		},
		getCheckTypes:function(success){
			App.doGet("/check/types",null,true, success);
		},
		getTypes:function(success){
			App.doGet("/asset/type/list",null,true,success);
		},
		
		loadType:function(id,success){
			App.doGet("/asset/type/load/"+id, null,true,success);
		},
		
		createType:function(name,success){
			App.doPost(
				"/asset/type/create",
				{ name: name },
				true,
				App.contentType.formData,
				success
			);
		},
		updateType: function (type, success) {
			App.doPost(
				"/asset/type/update",
				type,
				true,
				App.contentType.json,
				success
			);
		},
		deleteType: function (id, success) {
			App.doPost(
				"/asset/type/delete",
				{id:id},
				true,
				App.contentType.formData,
				success
			);
		},

		findAssets:function(condition,success){
			App.doPost(
				"/asset/findAssets",
				condition,
				true,
				App.contentType.formData,
				success
			);
		},
		  
		findAssetsByPositions: function (positionIds,success) {
			App.doPost(
				"/asset/findAssetsByPositions",
				positionIds,
				true,
				App.contentType.json,
				success
			);
		},

		findAssetsByTypes: function (typeIds,success) {
			App.doPost(
				"/asset/findAssetsByTypes",
				typeIds,
				true,
				App.contentType.json,
				success
			);
		},

		getOne: function (id,success) {
			App.doGet("/asset/load/" + id,null,true, success);
		},

		save: function (asset,success) {
			if (asset.id==null){
				App.doPost(
					"/asset/create",
					asset,
					true,
					App.contentType.json,
					success
				);
			}else{
				App.doPost(
					"/asset/update",
					asset,
					true,
					App.contentType.json,
					success
				);
			}
		},

		getOneByCode: function (code,success) {
			App.doGet("/asset/getOneByCode/" + code,null,true, success);
		},

		getFaultReports: function (assetId,success) {
			
		},

		saveFaultReport: function (report,success) {
		   
		},

		getFaultReport: function (reportId,success) {
		   
		},
		removeFaultReport: function (reportId,success) {
			
		},

		getInboundBills: function (condition,success) {
			App.doPost(
				"/inbound/bill/list",
				condition,
				true,
				App.contentType.formData,
				success
			);
		},

		getInboundBill: function (id,success) {
			App.doGet(
				"/inbound/bill/load/"+id,
				null,
				true,
				success
			);
		},

		addInboundBillItem:function(billId,assetCode,success){
			App.doPost(
				"/inbound/item/add",
				{billId:billId,code:assetCode},
				true,
				App.contentType.formData,
				success
			);
		},



		loadInboundBillItem:function(itemId,success){
			App.doGet(
				"/inbound/item/load/" + itemId,
				null,
				true,
				success
			);
		},

		updateInboundBillItem:function(item,success){
			App.doPost(
				"/inbound/item/update",
				item,
				true,
				App.contentType.json,
				success
			);
		},

		removeItemFromInboundBill: function (billId, itemId,success) {
			App.doPost(
				"/inbound/item/remove",
				{ billId: billId, itemId: itemId },
				true,
				App.contentType.formData,
				success
			);
		},

		getOutboundBill: function (id,success) {    
			App.doGet(
				"/outbound/bill/load/" + id,
				null,
				true,
				success
			);
		},

		getOutboundBills: function (condition, success) {
			App.doPost(
				"/outbound/bill/list",
				condition,
				true,
				App.contentType.formData,
				success
			);
		},

		
		getCheckBills: function (condition, success) {
			App.doPost(
				"/check/bill/list",
				condition,
				true,
				App.contentType.formData,
				success
			);
		},
		getCheckBill: function (id, success) {
			App.doGet(
				"/check/bill/load/" + id,
				null,
				true,
				success
			);
		},
		

		loadCheckItem:function(itemId,success){
			App.doGet(
				"/check/item/load/" + itemId,
				null,
				true,
				success
			);
		},

		appendPhotoToCheckItem:function(localPath,data,success){
			App.upload("/check/item/photo/upload",localPath,data,success);
		},

		removePhotoFromCheckItem: function (photoId,itemId,success){
			App.doPost(
				"/check/item/photo/remove",
				{ photoId: photoId,itemId:itemId },
				App.contentType.formData,
				success
			);
		},
	
		 /*领用模块开始*/
	  getTakeBills: function (condition, success) {
		
		App.doPost(
		  "/take/bill/list",
		  condition,
		  true,
		  App.contentType.formData,
		  success
		);
	  },

	  getTakeBill: function (id, success) {
		
		App.doGet(
		  "/take/bill/load/" + id,
		  null,
		  true,
		  success
		);
	  },

	}
});
