$.fn.wrapTableAsSelectAble = function(){
	var table = $(this);
	table.children("tbody").children("tr").each(function(){
		$(this).on("click",function(){
			$(this).parent().children("tr").removeClass("focused");
			$(this).addClass("focused");
		})
	});
}