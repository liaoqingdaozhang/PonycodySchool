
var Constants = {};
//Constants.HOST = 'https://host:port';
Constants.HOST = 'http://localhost';